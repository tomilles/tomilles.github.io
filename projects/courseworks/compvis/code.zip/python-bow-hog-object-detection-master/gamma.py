from __future__ import print_function
from __future__ import division
import cv2 as cv
import numpy as np
import argparse
import os
import random




def gamma(img_yuv,gamma=1):
    # [changing-contrast-brightness-gamma-correction]
    lookUpTable = np.empty((1,256), np.uint8)
    for i in range(256):
        lookUpTable[0,i] = np.clip(pow(i / 255.0, gamma) * 255.0, 0, 255)

    gamma_out = cv.LUT(img_yuv, lookUpTable)
    return gamma_out
    
    # img_gamma_corrected = cv.hconcat([res2]);

    # cv.imshow("Gamma correction", gamma_out);


def preprocess_main(input_image,gammaval,equalizeHist=True):
    parser = argparse.ArgumentParser(description='Code for Changing the contrast and brightness of an image! tutorial.')
    parser.add_argument('--input', help='Path to input image.', default='lena.jpg')
    args = parser.parse_args()

    # filename_list=list(sorted(os.listdir('../../TTBB-durham-02-10-17-sub10/left-images/')))

    # for file in filename_list:
    # img_original=cv.imread('../../TTBB-durham-02-10-17-sub10/left-images/{}'.format(file))
    img_original=input_image

    if equalizeHist:
        img_yuv = cv.cvtColor(img_original, cv.COLOR_BGR2YUV)
        img_yuv[:,:,0] = cv.equalizeHist(img_yuv[:,:,0])
        img_original = cv.cvtColor(img_yuv, cv.COLOR_YUV2BGR)

    preprocessed_image=gamma(img_original,gammaval)

    # cv.waitKey(100)
    return preprocessed_image


#####################################################################

# Example : load, display and compute SGBM disparity
# for a set of rectified stereo images from a  directory structure
# of left-images / right-images with filesname DATE_TIME_STAMP_{L|R}.png

# basic illustrative python script for use with provided stereo datasets

# Author : Toby Breckon, toby.breckon@durham.ac.uk

# Copyright (c) 2017 Department of Computer Science,
#                    Durham University, UK
# License : LGPL - http://www.gnu.org/licenses/lgpl.html

#####################################################################

import cv2
import os
import numpy as np
import scipy.stats as ss
import math
from matplotlib import pyplot as plt
from collections import Counter
from decimal import Decimal

# FROM manual: stereoProcessor = cv2.StereoSGBM(numDisparities=128, SADWindowSize=21);

# From help(cv2): StereoBM_create(...)
#        StereoBM_create([, numDisparities[, blockSize]]) -> retval
#
#    StereoSGBM_create(...)
#        StereoSGBM_create(minDisparity, numDisparities, blockSize[, P1[, P2[,
# disp12MaxDiff[, preFilterCap[, uniquenessRatio[, speckleWindowSize[, speckleRange[, mode]]]]]]]]) -> retval


"""CONCLUSION : ORDER DOES NOT MATTER, only the frequency of the elements!"""

# figure=np.zeros((255,255,3),np.uint8)
# for i in range(255): 
#     figure[:,i-1,:]=255-i
# figure=figure[:,(math.floor(figure.shape[1]/2)):]
# cv2.imshow('test',figure)
# cv2.waitKey(0)


# print(np.sum(figure[:,:figure.shape[1]]))
# print(np.sum(figure[:,figure.shape[1]:]))
# cv2.imwrite('h_L_gray_transition.png',figure)

def disparity_calc(imgL,imgR,max_disparity=128,power=0.8,noisefilter=5,pure=bool):
    stereoProcessor = cv2.StereoSGBM_create(0, max_disparity, 21);
    # from the left image filename get the correspondoning right image


    # remember to convert to grayscale (as the disparity matching works on grayscale)
    # N.B. need to do for both as both are 3-channel images

    grayL_0 = cv2.cvtColor(imgL,cv2.COLOR_BGR2GRAY);
    grayR_0 = cv2.cvtColor(imgR,cv2.COLOR_BGR2GRAY);

    # perform preprocessing - raise to the power, as this subjectively appears
    # to improve subsequent disparity calculation

    grayL = np.power(grayL_0.copy(), power).astype('uint8');
    grayR = np.power(grayR_0.copy(), power).astype('uint8');

    # compute disparity image from undistorted and rectified stereo images
    # that we have loaded
    # (which for reasons best known to the OpenCV developers is returned scaled by 16)

    disparity = stereoProcessor.compute(grayL,grayR);

    # filter out noise and speckles (adjust parameters as needed)

    dispNoiseFilter = noisefilter; # increase for more agressive filtering default 5
    cv2.filterSpeckles(disparity, 0, 4000, max_disparity - dispNoiseFilter);

    # scale the disparity to 8-bit for viewing
    # divide by 16 and convert to 8-bit image (then range of values should
    # be 0 -> max_disparity) but in fact is (-1 -> max_disparity - 1)
    # so we fix this also using a initial threshold between 0 and max_disparity
    # as disparity=-1 means no disparity available

    _, disparity = cv2.threshold(disparity,0, max_disparity * 16, cv2.THRESH_TOZERO);
    disparity_scaled = (disparity / 16.).astype(np.uint8);
    # print(disparity_scaled.shape)

    # crop disparity to chop out left part where there are with no disparity
    # as this area is not seen by both cameras and also


    # chop out the bottom area (where we see the front of car bonnet)

    # display image (scaling it to the full 0->255 range based on the number
    # of disparities in use for the stereo part)
    if pure:
        return disparity_scaled
    elif not pure:
        return cv2.equalizeHist((disparity_scaled.copy() * (256. / max_disparity)).astype(np.uint8))
    # return disparity_scaled
    # cv2.waitKey(0)


def disp_distribution(rectangle,threshtype,thresh_offset,min_disparity,min_ratio):

    rectangle_upper=rectangle[:math.floor(len(rectangle)*2/3),:]

    if rectangle_upper.shape[0]==0 or rectangle_upper.shape[1]==0:
        return -1

    h,w=rectangle_upper.shape[0],rectangle_upper.shape[1]

    rect_center=rectangle_upper.copy()[math.floor(h/4):math.floor(3*h/4),math.floor(w/4):math.floor(3*w/4)]
    # rect_outskirt=rectangle_upper[math.floor(h/4):math.floor(3*h/4),math.floor(w/4):math.floor(3*w/4)]
    rect_outskirt=rectangle_upper.copy()
    rect_outskirt[math.floor(h/4):math.floor(3*h/4),math.floor(w/4):math.floor(3*w/4)]=0
    # print(type(rect_center),rect_center.shape)
    # cv2.imshow('inside',rect_center)
    # cv2.imshow('before',rectangle_upper)

    rect_disp_val=np.ravel(rect_center)
    # print(Counter(rect_disp_val))
  
    most_common_disp=Counter(rect_disp_val).most_common(1)[0][0]
    
    if most_common_disp < min_disparity:
        # print('most common disparity is ',most_common_disp,', which is smaller than',min_disparity)
        # cv2.imshow('most common < min',rectangle_upper)
        return -1

    for i in range(len(rect_outskirt)):
        for j in range(len(rect_outskirt[i])):
            if rect_outskirt[i,j]>most_common_disp:
                rectangle_upper[i,j]=most_common_disp
    # cv2.imshow('after',rectangle_upper)
    # cv2.waitKey(0)

    ret,thresh_rect = cv2.threshold(rectangle_upper,most_common_disp-thresh_offset,255,threshtype)

    # thresh=cv2.hconcat([rectangle_upper,thresh_rect])
    # cv2.namedWindow('thresh',cv2.WINDOW_NORMAL)
    # cv2.resizeWindow('thresh',2*rectangle_upper.shape[0]+100,rectangle_upper.shape[1]+100)
    # cv2.moveWindow('thresh',850,50)
    # cv2.imshow('thresh',thresh)
    # cv2.waitKey(0)

    # cv2.destroyAllWindows()

    return thresh_check(thresh_rect,min_ratio,rectangle_upper)


def thresh_check(binary_img,min_ratio,rectangle_upper):
    normal_img=cv2.imread('human_disparity.png',0)
    # normal_img=cv2.threshold(cv2.imread('normal.png',0),200,255,cv2.THRESH_BINARY_INV)[1]
    # normal_img=cv2.threshold(normal_img,1,255,cv2.THRESH_BINARY)[1]

    normal_img=cv2.resize(normal_img,(binary_img.shape[1],binary_img.shape[0]))
    normal_img=cv2.threshold(normal_img,127,255,cv2.THRESH_BINARY_INV)[1]

    # combined=cv2.hconcat([normal_img,binary_img,rectangle_upper])
    # cv2.namedWindow('combined',cv2.WINDOW_NORMAL)
    # cv2.moveWindow('combined',50,50)
    # cv2.imshow('combined',combined)
    # cv2.waitKey(0)
    comparison=np.equal(binary_img,normal_img)
    hit_ratio=np.sum(comparison)/comparison.size
    # print('similarity=',hit_ratio)
    if hit_ratio >min_ratio:
        return 1
    else:
        return -1
  

def project_disparity_to_3d(disparity):


    camera_focal_length_px = 399.9745178222656  # focal length in pixels
    camera_focal_length_m = 4.8 / 1000          # focal length in metres (4.8 mm)
    stereo_camera_baseline_m = 0.2090607502 

    f = camera_focal_length_px;
    B = stereo_camera_baseline_m;

    h,w=disparity.shape[0],disparity.shape[1]

    disp_rect_center=disparity.copy()[math.floor(h/4):math.floor(3*h/4),math.floor(w/4):math.floor(3*w/4)]

    rect_disp_val=np.ravel(disp_rect_center)

    most_common_disp=Counter(rect_disp_val).most_common(1)[0][0]

    # Zmax = ((f * B) / d);

    Z = (f * B) / most_common_disp

    distance=Decimal(Z)

    try:
        distance=round(distance,1)
        return distance
    except Exception:
        return Z

    

#####################################################################

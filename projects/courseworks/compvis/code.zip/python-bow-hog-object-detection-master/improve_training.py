import cv2 
import random
import numpy as np
import glob


def translate_image(image, pos_range=2):
    """Perturbs the image by translating the image by - pos_range to + pos_range pixels"""
    rows, cols = image.shape[:2] 
    pos_x = pos_range * np.random.uniform() - pos_range/2
    pos_y = pos_range * np.random.uniform() - pos_range/2
    scaling=(list([random.randint(92,108)/100,random.randint(92,108)/100,random.randint(-8,8)/100,random.randint(-8,8)/100]))
    pos_M = np.float32([[scaling[0],scaling[2], pos_x],[scaling[3], scaling[1], pos_y]])
    image=cv2.warpAffine(image, pos_M, (cols,rows))

    return image

def crop_and_resize(image):
    """Perturbs the image by the scale randomly selected from the 'scale' array"""
    scaling=random.randint(1,25)
    image=image[scaling:(160-scaling),scaling:(96-scaling),:]
    image=cv2.resize(image,(96,160))

    return image

def rotate_image(image):
    """Perturbs the image by rotation it by an angle randomly selected from rot_rangle"""
    rows, cols = image.shape[:2] 
    rot=random.randint(-80,80)/10
    rot_M = cv2.getRotationMatrix2D((cols/2, rows/2), rot, 1)
    
    image=cv2.warpAffine(image, rot_M, (cols,rows))
    return image


def apply_brightness_contrast(input_img, brightness = 0, contrast = 0):
    if brightness != 0:
        if brightness > 0:
            shadow = brightness
            highlight = 255
        else:
            shadow = 0
            highlight = 255 + brightness
        alpha_b = (highlight - shadow)/255
        gamma_b = shadow

        buf = cv2.addWeighted(input_img, alpha_b, input_img, 0, gamma_b)
    else:
        buf = input_img.copy()

    if contrast != 0:
        f = 131*(contrast + 127)/(127*(131-contrast))
        alpha_c = f
        gamma_c = 127*(1-f)

        buf = cv2.addWeighted(buf, alpha_c, buf, 0, gamma_c)

    return buf

def transform_image(image, pos_range = 2, rot_range = 2, scale = [1, 1.1], affine_range = 2):    
    image = crop_and_resize(image)
    image = rotate_image(image)
    image = translate_image(image, pos_range=2)
    b=random.randint(-100,100)
    c=random.randint(-50,50)
    image=apply_brightness_contrast(image,b,c)

    is_blurred = random.sample([0, 1], 1)
    if is_blurred[0]:
        image = cv2.GaussianBlur(image,(3,3),0)
   
    return image

def main_improve():
    for file in glob.glob("../INRIAPerson/train_64x128_H96/pos/*.png"):
        inputimage=cv2.imread(file)
        # print(file)
        for i in range(2):
            print("{}_{}".format(file[36:-4],i))
            # cv2.imwrite("../INRIAPerson/train_64x128_H96/pos/{}_transformed_{}.png".format(file[36:-4],i),transform_image(inputimage))
            cv2.imshow('foo',transform_image(inputimage))
            # cv2.waitKey(20)
            # transform_image(inputimage)
            cv2.moveWindow('foo',600,600)
            cv2.waitKey(1000)
    return
if __name__ == '__main__':
    main_improve()


   
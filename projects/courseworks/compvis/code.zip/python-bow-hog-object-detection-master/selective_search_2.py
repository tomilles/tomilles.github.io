#####################################################################

# Example : performs selective search bounding box identification

# Author : Toby Breckon, toby.breckon@durham.ac.uk
# Copyright (c) 2018 Department of Computer Science, Durham University, UK

# License: MIT License

# ackowledgements: based on the code and examples presented at:
# https://www.learnopencv.com/selective-search-for-object-detection-cpp-python/

#####################################################################

import cv2
import os
import sys
import math
import numpy as np
from sliding_window import *
from utils import *

#####################################################################

# press all the go-faster buttons - i.e. speed-up using multithreads

cv2.setUseOptimized(True);
cv2.setNumThreads(20);
svm = cv2.ml.SVM_load('svm_hog_ori.xml')

#####################################################################

# directory_to_cycle = "../../TTBB-durham-02-10-17-sub10/left-images" # edit this

#####################################################################

# create Selective Search Segmentation Object using default parameters

ss = cv2.ximgproc.segmentation.createSelectiveSearchSegmentation()

#####################################################################

# loop all images in directory (sorted by filename)




def selective_search(image,rect_number):
    detections=[]
    # read image from file

    # frame = cv2.imread(os.path.join(directory_to_cycle, filename), cv2.IMREAD_COLOR)
    frame = image
    frame_ori=frame.copy()
    frame_ori_2=frame_ori.copy()
    # start a timer (to see how long processing and display takes)

    start_t = cv2.getTickCount();

    # set input image on which we will run segmentation

    ss.setBaseImage(frame)
    # print(frame.shape)


    # Switch to fast but low recall Selective Search method
    # ss.switchToSelectiveSearchFast()

    # Switch to high recall but slow Selective Search method (slower)
    ss.switchToSelectiveSearchQuality()

    # run selective search segmentation on input image

    # this gives all kind of regions for objects
    rects = ss.process() # x, y, w, h = rect

    # print('Total Number of Region Proposals: {}'.format(len(rects)))

    # number of region proposals to show
    numShowRects = rect_number
    # print(rects[0])
    blocks=np.array([])

    # iterate over all the region proposals
    for i, rect in enumerate(rects):
        # print(rect)
        # draw rectangle for region proposal till numShowRects
        if (i < numShowRects):
            x, y, w, h = rect
            
            #here we choose those which have suitable sizes
            
            if (w*0.5 < h < w*3.0) and h>32 and w>16:
                block=frame_ori_2[y:(y+h),x:(x+w)]
                # cv2.imshow('1',block)
                # cv2.waitKey(0)

                # display those which have suitable sizes    

                # cv2.rectangle(frame, (x, y), (x+w, y+h), (0, 255, 0), 1, cv2.LINE_AA)
                # cv2.imshow('ss_1',frame)
                # cv2.waitKey(20)

                # run the regions in the svm classifier

                img_data = ImageData(block)
                img_data.compute_hog_descriptor();

                if img_data.hog_descriptor is not None:

                        # print("detecting with SVM ...")

                        retval, [result] = svm.predict(np.float32([img_data.hog_descriptor]))

                        # print(result)

                        # if we get a detection, then record it

                        if result[0] == params.DATA_CLASS_NAMES["pedestrian"]:

                            # so far i got: rectangle indices not in line wth the actual ones, hence the disparity is calculated for the wrong indices


                            rect_2 = ([x, y, x + w, y + h])
                            # print(rect_2)
                            
                            detections.append(rect_2)
                # cv2.imshow('frame',block)
                # cv2.waitKey(0)
        else:
            break

            # sort out overlapping boxes
    detections = non_max_suppression_fast(np.int32(np.float32(detections)), 1)
    # for rect in detections:
    #         cv2.rectangle(frame_ori, (rect[0], rect[1]), (rect[2], rect[3]), (0, 0, 255), 2)

    # cv2.imshow('detected objects',frame_ori)
    # key = cv2.waitKey(0) # wait 200ms

    stop_t = ((cv2.getTickCount() - start_t)/cv2.getTickFrequency()) * 1000;

    # print('Processing time (ms): {}'.format(stop_t))
    # print()

    # start the event loop - essential

    # wait 40ms or less depending on processing time taken (i.e. 1000ms / 25 fps = 40 ms)

    # key = cv2.waitKey(max(40, 40 - int(math.ceil(stop_t)))) & 0xFF;

    # It can also be set to detect specific key strokes by recording which key is pressed

    # e.g. if user presses "x" then exit / press "f" for fullscreen

    ss.clearImages()
    return frame_ori,detections
    # imgL[:80,:,:]=0
    #     imgL[390:,:,:]=0

# close all windows

    cv2.destroyAllWindows()

#####################################################################

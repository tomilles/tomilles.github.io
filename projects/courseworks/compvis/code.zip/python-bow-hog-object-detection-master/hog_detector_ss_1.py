import cv2
import os
import numpy as np
import math
import params
from utils import *
from sliding_window import *
from stereo_disparity_2 import *
from selective_search_2 import*
import sys
from gamma import *
import random




# directory for L and R images

master_path_to_dataset = "../TTBB-durham-02-10-17-sub10/"

################################################################################

directory_to_cycle = os.path.join(master_path_to_dataset,"left-images")
directory_to_cycle_R = os.path.join(master_path_to_dataset,"right-images")


################################################################################


# parameters used in the program
### CHANGE uniform_disp_check TO SKIP UNIFORM CHECKING###
non_max_sup_1=0.9
non_max_sup_2=0.7
rtol=2
atol=2
uniform_disp_check = True

# load trained SVM
try:

    svm = cv2.ml.SVM_load('svm_hog_ori.xml')
except:
    print("Missing files - SVM!");
    print("-- have you performed training to produce these files ?");
    exit();



# process all images in directory (sorted by filename)



for filename in sorted(os.listdir(directory_to_cycle)):


    if '.png' in filename:
        distance_list=[]

        # read image data
        imgL = cv2.imread(os.path.join(directory_to_cycle, filename), cv2.IMREAD_COLOR)         ### at uni PCs sometimes the images were not able to read due to libpng error!
        imgR = cv2.imread(os.path.join(directory_to_cycle_R, "{}R.png".format(filename[:-5])), cv2.IMREAD_COLOR)
        imgL_trimmed=imgL.copy()[100:390,:,:]
        imgR_trimmed=imgR.copy()[100:390,:,:]
        img_trimmed=imgL.copy()[100:390,135:,:]
        img_trimmed_processed=preprocess_main(img_trimmed.copy(),gammaval=0.8,equalizeHist=True)
        img_trimmed_uniform=img_trimmed.copy()
        # PREPROCESSING
        # gamma correction

        imgL[:100,:,:]=0
        imgL[390:,:,:]=0
        imgL[:,:135,:]=0
        imgR[:,:135,:]=0
        imgR[:100,:,:]=0
        imgR[390:,:,:]=0
       

        processed_imgL_full=preprocess_main(imgL,gammaval=0.8,equalizeHist=True)
        
        ss_frame, detections = selective_search(processed_imgL_full.copy(),rect_number=4000)
        # print(ss_frame.shape==processed_imgL_full.shape)
        # cv2.imshow('ss_frame',ss_frame)
        # exit()
        
        pure_disparity_img=disparity_calc(imgL_trimmed.copy(), imgR_trimmed.copy(),max_disparity=128,power=1,noisefilter=10,pure=True)[:,135:]

        # preprocess for disparity
        imgL_disp=preprocess_main(imgL_trimmed,gammaval=0.5,equalizeHist=False)
        imgR_disp=preprocess_main(imgR_trimmed,gammaval=0.5,equalizeHist=False)

        disparity_img=disparity_calc(imgL_disp, imgR_disp,max_disparity=128,power=0.7,noisefilter=10,pure=False)[:,135:]

        #### SLIDING WINDOW ####


        overall_detection=[]


        for rect in detections:
            found=0
            x1,y1,x2,y2=rect[:]
            # making sure the black parts are cut off
            x1=x1-135
            x2=x2-135
            y1=y1-100
            y2=y2-100
            # cv2.rectangle(img_trimmed, (x1, y1), (x2, y2), (0, 0, 255), 3)

            # print(rect)

            output_img=img_trimmed_processed.copy()[y1:y2,x1:x2]



            # for a range of different image scales in an image pyramid

            current_scale = -1
            detections_sliding = []
            rescaling_factor = 1.1

            ################################ for each re-scale of the image
            if output_img.shape[0]>=128 and output_img.shape[1]>=64:

                for resized in pyramid(output_img, scale=rescaling_factor):

                    # at the start our scale = 1, because we catch the flag value -1

                    if current_scale == -1:
                        current_scale = 1

                    # after this rescale downwards each time (division by re-scale factor)

                    else:
                        current_scale = current_scale / rescaling_factor

                    # print(current_scale)
                    rect_img = resized.copy()
                    # cv2.imshow('rect_img',rect_img)
                    # cv2.waitKey(0)

                    # loop over the sliding window for each layer of the pyramid (re-sized image)

                    window_size = params.DATA_WINDOW_SIZE
                    # print(rect_img.shape)
                    step = math.floor(resized.shape[0] / 16) #original 16
                    # step=1

                    if step > 0:

                        ############################# for each scan window

                        for (x, y, window) in sliding_window(resized, window_size, step_size=step):

                            # if we want to see progress show each scan window
                            # print (x,y)


                            # for each window region get the BoW feature point descriptors

                            img_data_sliding = ImageData(window)
                            img_data_sliding.compute_hog_descriptor();

                            # generate and classify each window by constructing a BoW
                            # histogram and passing it through the SVM classifier

                            if img_data_sliding.hog_descriptor is not None:
                                


                                retval, [result_rounded] = svm.predict(np.float32([img_data_sliding.hog_descriptor]))



                                # if we get a detection, then record it


                                if result_rounded[0] == params.DATA_CLASS_NAMES["pedestrian"]:
                                    found+=1
                                    # store rect as (x1, y1) (x2,y2) pair

                                    rect = np.float32([x, y, x + window_size[0], y+ window_size[1]])
                                    rect *= (1.0 / current_scale)
                                    rect=np.float32([rect[0]+x1,rect[1]+y1,rect[2]+x1,rect[3]+y1])

                                    # cv2.rectangle(img_trimmed,(rect[0],rect[1]),(rect[2],rect[3]),(0,255,255),2)
                                    detections_sliding.append(rect)

                        ########################################################

                
            else:
                found=0
            # For the overall set of detections (over all scales) perform
            # non maximal suppression (i.e. remove overlapping boxes etc).

            detections_sliding = non_max_suppression_fast(np.int32(detections_sliding), non_max_sup_1)

            for rect_0 in detections_sliding:
                overall_detection.append(np.int32([rect_0[0], rect_0[1], rect_0[2], rect_0[3]]))
            

                # finally draw all the detection on the original image
            

            if found<2:
                # print('found')
                if 0<(x2-x1)<=(y2-y1):
                    overall_detection.append(np.int32([x1, y1, x2, y2]))
            
        
        overall_detection = non_max_suppression_fast(np.int32(overall_detection), non_max_sup_2)

        for box in overall_detection:
            disparity_img_color=cv2.cvtColor(disparity_img.copy(), cv2.COLOR_GRAY2BGR)
            disp_rect=disparity_img.copy()[box[1]:box[3],box[0]:box[2]]

            disp_result = disp_distribution(disp_rect.copy(),threshtype=cv2.THRESH_BINARY,thresh_offset=20,min_disparity=30,min_ratio=0.65)
            if disp_result == 1:
                pure_disparity_img_rect=pure_disparity_img.copy()[box[1]:box[3],box[0]:box[2]]
                distance=project_disparity_to_3d(pure_disparity_img_rect)
                if distance < 50:
                    distance_list.append(distance)

                    #check against directed black-white blending 
                    if uniform_disp_check:

    #### check if its uniformly distributed or not: means ther's no object just a region close to the car 

                        gray_max=np.amax(disp_rect)
                        gray_min = np.amin(np.array(disp_rect)[disp_rect != np.amin(disp_rect)])
                        shape=int(gray_max-gray_min)

                        if shape == 0:
                            cv2.rectangle(img_trimmed, (box[0],box[1]), (box[2],box[3]), (0, 0, 255), 3)
                            if box[3]+20 > img_trimmed.shape[0]:
                                if box[1]-10 < 0:
                                    cv2.putText(img_trimmed,'P:{}m'.format(distance),(box[0],box[3]-10),cv2.FONT_HERSHEY_PLAIN ,1.2,(0, 0, 255),1,cv2.LINE_AA)
                                else:
                                    cv2.putText(img_trimmed,'P:{}m'.format(distance),(box[0],box[1]-10),cv2.FONT_HERSHEY_PLAIN ,1.2,(0, 0, 255),1,cv2.LINE_AA)
                            else:
                                cv2.putText(img_trimmed,'P:{}m'.format(distance),(box[0]+2,box[3]+20),cv2.FONT_HERSHEY_PLAIN ,1.2,(0, 0, 255),1,cv2.LINE_AA)
                            continue
                        figure=np.zeros((shape,shape),np.uint8)


                        L_R_half=math.floor(disp_rect.shape[1]/2)
                        U_D_half=math.floor(disp_rect.shape[0]/2)

                        L_to_R=int(np.sum(disp_rect[:,:L_R_half]))-int(np.sum(disp_rect[:,L_R_half:]))
                        R_to_L=int(np.sum(disp_rect[:,L_R_half:]))-int(np.sum(disp_rect[:,:L_R_half]))
                        Down_to_Up=int(np.sum(disp_rect[U_D_half:,:]))-int(np.sum(disp_rect[:U_D_half,:]))

                        maximum=max(L_to_R,R_to_L,Down_to_Up)
                        iteration=0
                        if maximum==L_to_R:
                            for k in range(gray_min,gray_max,1):
                                figure[:,iteration]=gray_max-k
                                iteration+=1

                        elif maximum==R_to_L:
                            for k in range(gray_min,gray_max,1):
                                figure[:,iteration]=k
                                iteration+=1

                        elif maximum== Down_to_Up:
                            for k in range(gray_min,gray_max,1):
                                figure[iteration,:]=k
                                iteration+=1
                        else:
                            print('error')
                        figure=cv2.resize(figure,(disp_rect.shape[1],disp_rect.shape[0]))

                        similarity=np.allclose(disp_rect,figure,rtol=rtol, atol=atol)

                        if similarity:
                            cv2.rectangle(img_trimmed_uniform, (box[0],box[1]), (box[2],box[3]), (100, 0, 100), 3)
                            continue

                    cv2.rectangle(img_trimmed, (box[0],box[1]), (box[2],box[3]), (0, 0, 255), 3)
                    if box[3]+20 > img_trimmed.shape[0]:
                        if box[1]-10 < 0:
                            cv2.putText(img_trimmed,'P:{}m'.format(distance),(box[0],box[3]-10),cv2.FONT_HERSHEY_PLAIN ,1.2,(0, 0, 255),1,cv2.LINE_AA)
                        else:
                            cv2.putText(img_trimmed,'P:{}m'.format(distance),(box[0],box[1]-10),cv2.FONT_HERSHEY_PLAIN ,1.2,(0, 0, 255),1,cv2.LINE_AA)
                    else:
                        cv2.putText(img_trimmed,'P:{}m'.format(distance),(box[0]+2,box[3]+20),cv2.FONT_HERSHEY_PLAIN ,1.2,(0, 0, 255),1,cv2.LINE_AA)
                    

                else:
                    # print('too far')
                    pass
    cv2.putText(img_trimmed,'Final detections',(10,20),cv2.FONT_HERSHEY_PLAIN ,1.5,(0,0,0),2,cv2.LINE_AA)
    cv2.putText(img_trimmed_uniform,'Removed detections',(10,20),cv2.FONT_HERSHEY_PLAIN ,1.5,(0,0,0),2,cv2.LINE_AA)
    disp_and_trimmed=cv2.vconcat([disparity_img_color,img_trimmed,img_trimmed_uniform])

    if distance_list==[]:
        nearest_obj=0
    else:
        nearest_obj=min(distance_list)

    print(filename)
    print("{}R.png : nearest detected scene object ({}m)".format(filename[:-5],nearest_obj))
    cv2.namedWindow('final',cv2.WINDOW_NORMAL)
    cv2.resizeWindow('final',600,650)
    cv2.imshow('final',disp_and_trimmed)

    cv2.waitKey(10)





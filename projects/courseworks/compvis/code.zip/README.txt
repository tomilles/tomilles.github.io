how to execute the program

1. make sure libpng is up to date, as this causes issues on lab PCs
2. the main script is python-bow-hog-object-detection-master/hog_detector_ss_1.py
3. on the top of this script there is the master path, edit this as needed
4. simply execute hog_detector_ss_1.py from its folder through terminal
5. the window contains 3 subwindows, top one is disparity map, middle one is detections and ranging, bottom one is eliminated detections with uniform transition test
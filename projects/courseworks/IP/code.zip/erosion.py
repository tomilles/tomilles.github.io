import cv2
import numpy as np
import sys

iterations=1		# defining number of iterations
image = cv2.imread('{0}'.format(sys.argv[1]),0)	#import image from the same folder as the this file in

def erosionfunction(img):
	'''This function erodes the input image with a predefined 5x5 square structuring element, and saves the output image.'''

	img_erode=np.zeros(img.shape,dtype='uint8') #creating a matrix of zeros of the same shape as the imported picture

	for i in range(len(img)):							# scan each pixel of the image one by one with a 5x5 structuring element
		for j in range(len(img)):
			if j>1 and i > 1:
				kernel=(img[(i-2):(i+3),(j-2):(j+3)])	# matrix with the shape of the structuring element around the current pixel
				img_erode[i,j]=int(np.min(kernel))		# using the definition of erosion, set the current pixel to the eroded version of the original pixel based on the 5x5 kernel
			elif i==1 and j>1:
				kernel=(img[(i-1):(i+3),(j-2):(j+3)])		# on the boundary of the image, define kernel such that it stays within the boundaries of the picture
				img_erode[i,j]=int(np.min(kernel))
			elif i==0 and j>1:
				kernel=(img[(i):(i+3),(j-2):(j+3)])
				img_erode[i,j]=int(np.min(kernel))
			elif j==1 and i>1:
				kernel=(img[(i-2):(i+3),(j-1):(j+3)])
				img_erode[i,j]=int(np.min(kernel))
			elif j==0 and i>1:
				kernel=(img[(i-2):(i+3),(j):(j+3)])
				img_erode[i,j]=int(np.min(kernel))
			elif j<2 and i < 2:
				kernel=(img[0:(i+3),0:(j+3)])
				img_erode[i,j]=int(np.min(kernel))
	return img_erode

img_erode=erosionfunction(image)		# executing the erosion function

cv2.imwrite('{0}'.format(sys.argv[2]),img_erode)	# save eroded image

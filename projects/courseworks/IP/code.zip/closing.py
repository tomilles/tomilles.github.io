import sys
from erosion import erosionfunction
from dilation import dilationfunction
import cv2

def closing():
	'''This function closes the input image by first dilating and then eroding the dilated image, both with a predefined 5x5 square structuring element, then it saves the output image.'''
	image = cv2.imread('{0}'.format(sys.argv[1]),0)		#import image from the same folder as the this file in
	dilate_image=dilationfunction(image)				# make a dilated image out of the original one by calling the dilation function from dilation.py
	closing_image=erosionfunction(dilate_image)			# by calling the erosion function from erosion.py, make an eroded image from the dilated one
	cv2.imwrite('{0}'.format(sys.argv[2]),closing_image)	#save the resulting image
closing()
import cv2
import numpy as np
import sys

iterations=1			# defining number of iterations
image = cv2.imread('{0}'.format(sys.argv[1]),0)			#import image from the same folder as the this file in

def dilationfunction(img):
	'''This function dilates the input image with a predefined 5x5 square structuring element, and saves the output image.'''

	img_dilate=np.zeros(img.shape,dtype='uint8')		# creating a matrix of zeros of the same shape as the imported picture
	for i in range(len(img)):							# scan each pixel of the image one by one with a 5x5 structuring element
		for j in range(len(img)):
			if j>1 and i > 1:
				kernel=(img[(i-2):(i+3),(j-2):(j+3)])		# matrix with the shape of the structuring element around the current pixel
				img_dilate[i,j]=int(np.max(kernel))		# using the definition of dilation, set the current pixel to the dilated version of the original pixel based on the 5x5 kernel
			elif i==1 and j>1:
				kernel=(img[(i-1):(i+3),(j-2):(j+3)])		# on the boundary of the image, define kernel such that it stays within the boundaries of the picture
				img_dilate[i,j]=int(np.max(kernel))
			elif i==0 and j>1:
				kernel=(img[(i):(i+3),(j-2):(j+3)])
				img_dilate[i,j]=int(np.max(kernel))
			elif j==1 and i>1:
				kernel=(img[(i-2):(i+3),(j-1):(j+3)])
				img_dilate[i,j]=int(np.max(kernel))
			elif j==0 and i>1:
				kernel=(img[(i-2):(i+3),(j):(j+3)])
				img_dilate[i,j]=int(np.max(kernel))
			elif j<2 and i < 2:
				kernel=(img[0:(i+3),0:(j+3)])
				img_dilate[i,j]=int(np.max(kernel))
	return img_dilate

img_dilate=dilationfunction(image)					# executing the dilation function

cv2.imwrite('{0}'.format(sys.argv[2]),img_dilate)	# save dilated image


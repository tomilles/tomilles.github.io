import sys
from erosion import erosionfunction
from dilation import dilationfunction
import cv2

def opening():
	'''This function opens the input image by first eroding and then dilating the eroded image, both with a predefined 5x5 square structuring element, then it saves the output image.'''
	image = cv2.imread('{0}'.format(sys.argv[1]),0)		#import image from the same folder as the this file in
	erode_image=erosionfunction(image)					# make an eroded image out of the original one by calling the erosion function from erosion.py
	opening_image=dilationfunction(erode_image)			# by calling the dilation function from dilation.py, make a dilated image from the eroded one
	cv2.imwrite('{0}'.format(sys.argv[2]),opening_image)	#save the resulting image
opening()
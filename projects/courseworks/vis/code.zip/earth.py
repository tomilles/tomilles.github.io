import vtk
import sys
import pyvista
from vtk.util.colors import *

# create a rendering window and renderer

reader = vtk.vtkXMLPolyDataReader()

if len(sys.argv) == 3:
	reader.SetFileName(sys.argv[1])
	image = sys.argv[2]
else:
	print('no input data defined')
	reader.SetFileName("/Users/Tomi/Dropbox/Masters lvl 4 year/SSA IV/visualisation/Dataset/elevation_medium.vtp")
	image = "/Users/Tomi/Dropbox/Masters lvl 4 year/SSA IV/visualisation/Dataset/worldTopo_medium.jpg"

imageReader = vtk.vtkJPEGReader()
imageReader.SetFileName(image)

texture = vtk.vtkTexture()
texture.SetInputConnection(imageReader.GetOutputPort())


warp = vtk.vtkWarpScalar()
warp.SetInputConnection(reader.GetOutputPort())
warp.SetScaleFactor(35)

contour = vtk.vtkContourFilter()
contour.SetInputConnection(warp.GetOutputPort())
contour.GenerateValues(19,-10000,8000)

def tubesradius(obj,event):
	global tubes
	rep = obj.GetRepresentation()
	tubes.SetRadius(rep.GetValue())
def elevationscale(obj,event):
	global warp
	rep = obj.GetRepresentation()
	warp.SetScaleFactor(rep.GetValue())


tubes = vtk.vtkTubeFilter()
tubes.SetInputConnection(contour.GetOutputPort())
tubes.SetRadius(10000)

colormap = vtk.vtkColorTransferFunction()

colormap.AddRGBPoint(-10000,64/255, 110/255, 1)
colormap.AddRGBPoint(8000,1,1,0)

above0 = colormap.GetColor(1)
below0 = colormap.GetColor(-1)

colormap.AddRGBPoint(1,above0[0],above0[1],above0[2])
colormap.AddRGBPoint(-1,below0[0],below0[1],below0[2])
colormap.AddRGBPoint(0,1,0,0)


mapper = vtk.vtkDataSetMapper()
mapper.SetInputConnection(tubes.GetOutputPort())
mapper.SetLookupTable(colormap)

spheremapper = vtk.vtkDataSetMapper()
spheremapper.SetInputConnection(warp.GetOutputPort())



ren = vtk.vtkRenderer()

renWin = vtk.vtkRenderWindow()
renWin.AddRenderer(ren)
renWin.SetSize(1000, 1000)
iren = vtk.vtkRenderWindowInteractor()

iren.SetRenderWindow(renWin)

widget_slider = vtk.vtkSliderWidget()
widget_slider.SetInteractor(iren)
rep = vtk.vtkSliderRepresentation2D()
rep.GetPoint1Coordinate().SetCoordinateSystemToNormalizedDisplay()
rep.GetPoint1Coordinate().SetValue(0.55, 0.07)
rep.GetPoint2Coordinate().SetCoordinateSystemToNormalizedDisplay()
rep.GetPoint2Coordinate().SetValue(0.95, 0.07)
rep.SetLabelFormat("%0.0f")
rep.SetMinimumValue(0)
rep.SetMaximumValue(30000)
rep.SetSliderLength(0.02)
rep.SetSliderWidth(0.05)
rep.GetSliderProperty().SetColor(0, 1, 1)
rep.SetValue(10000)
rep.GetTubeProperty().SetColor(1, 1, 1)
rep.GetCapProperty().SetColor(1, 1, 1)
rep.SetTitleText("tubes radius [ 0: off ]")
rep.GetTitleProperty().SetColor(1, 1, 1)
rep.GetLabelProperty().SetColor(1, 1, 1)
widget_slider.SetRepresentation(rep)
widget_slider.SetAnimationModeToJump()
widget_slider.AddObserver("InteractionEvent", tubesradius)
widget_slider.On()

widget_slider2 = vtk.vtkSliderWidget()
widget_slider2.SetInteractor(iren)
rep2 = vtk.vtkSliderRepresentation2D()
rep2.GetPoint1Coordinate().SetCoordinateSystemToNormalizedDisplay()
rep2.GetPoint1Coordinate().SetValue(0.05, 0.07)
rep2.GetPoint2Coordinate().SetCoordinateSystemToNormalizedDisplay()
rep2.GetPoint2Coordinate().SetValue(0.45, 0.07)
rep2.SetMinimumValue(0)
rep2.SetMaximumValue(200)
rep2.SetSliderLength(0.02)
rep2.SetSliderWidth(0.05)
rep2.GetSliderProperty().SetColor(0, 1, 1)
rep2.SetValue(35)
rep2.GetTubeProperty().SetColor(1, 1, 1)
rep2.GetCapProperty().SetColor(1, 1, 1)
rep2.SetTitleText("elevation scale [ 0: off ]")
rep2.GetTitleProperty().SetColor(1, 1, 1)
rep2.GetLabelProperty().SetColor(1, 1, 1)
widget_slider2.SetRepresentation(rep2)
widget_slider2.SetAnimationModeToJump()
widget_slider2.AddObserver("InteractionEvent", elevationscale)
widget_slider2.On()
# actor



actor = vtk.vtkActor()
actor.SetMapper(spheremapper)
actor.SetTexture(texture)

actor.GetProperty().SetRepresentationToSurface()
actor.GetProperty().SetSpecularColor(255, 255, 255)
actor.GetProperty().SetSpecular(1)
actor.GetProperty().SetSpecularPower(1)
actor.GetProperty().SetAmbientColor(255,255,255)
actor.GetProperty().SetAmbient(10)
actor.GetProperty().SetDiffuseColor(255,255,255)
actor.GetProperty().SetDiffuse(10)
actor.GetProperty().LightingOn()

isoactor = vtk.vtkActor()
isoactor.SetMapper(mapper)


# assign actor to the renderer
ren.AddActor(actor)
ren.AddActor(isoactor)
ren.SetBackground(0.5, 0.5, 0.5)
# # enable user interface interactor
iren.Initialize()
renWin.Render()

iren.Start()



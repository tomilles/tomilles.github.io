import math
import random

# Set the parameter of the problem.
dt=0.001  # simulation time increment
D=0.5;    # diffusion coef 
tmax = 100

def diffuse(t_max):
    """ Simulate the diffusion of a particle.
        Randomly move right or left by fixed step. Stop when t=t_max
        and return the position reached.
        Uses global variables D and dt
    """
    x = 0.0
    dr = math.sqrt(2*D*dt)
    # Evolve
    t =0;
    while (t < t_max): # diffuse until tmax
        rnd = random.random() # a random number between 0 and 1
        direction = 1  # default: move right
        if(rnd < 0.5):
          direction = -1 # move left (50% chance)
        x += direction*dr
        t += dt
    return(x)

# Solution
import numpy as np
import matplotlib.pyplot as plt

Nmax = 10000
Nbins = 50

x = []
##### TO DO ############
# execute the function diffuse(tmax) Nmax time and append the results
# in the list x
########################

# Produce a histogram of the collected data in x
# bins: the list of x values of the center of the histogram bins
n, bins, patches = plt.hist(x, Nbins, normed=1, facecolor='green', alpha=0.5)

##### TO DO ############
# Plot the theoretical solution d(tmax) of the diffusion equation
# on top of the hyitogram produced above
# bins is a list of x value for the center of the bins
########################

plt.xlabel('X')
plt.ylabel('Probability')
plt.title(r'$\mathrm{Histogram\ of\ Diffusion:}$')
plt.grid(True)

plt.show()

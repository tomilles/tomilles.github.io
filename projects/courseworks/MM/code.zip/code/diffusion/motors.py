import math
import random
import numpy as np
import matplotlib.pyplot as plt

class Motor:
    """ A class to simulate the random displacement of a motor
        draging a load.
    """

    def __init__(self):
        """ Initialise several phisical constant
        """
        self.d = 8e-9          # dynein step size 8 nm 
        self.v = 8.5e-7        # average dynein speed 
        self.Fstall = 1.25e-12 # dynein stall force
        self.Fd = 8.7e-13      # detachment force
        self.lambdaF= 1.97e-12 # 
        self.kd0= 1            # detachment rate under zero load
        self.kBT = 4.14e-23    # in Joules
        self.eta = 2e-3        # water viscosity 0.001 Pa s, cell: *2
        self.x_list = []       # list used for figures
        self.t_list = []
        
    def F_load(self,r):
        """ Compute F_load as a function of the cargo radius
        """
        #### TO DO #####

    def kp(self,r):
        """ Compute forward step rate as a function of r
        """
        #### TO DO #####

    def kd(self,r):
        """ Compute the detachment rate as a function of r
        """
        F=self.F_load(r)
        #### TO DO #####

    def evolve(self,r,dt_fig,mk_fig=False):
        """ Simulate the walk of the motor until it detaches
            r : radius of cargo
            mk_fig : if true: collect data for figure
        """
        x = 0 # initial position
        t = 0 # initial time
        next_t_fig = dt_fig # next time for figure output
        self.x_list = [0] # list of x for figure. Start at 0
        self.t_list = [0] # list of t for figure. Start at 0
        
        kp = self.kp(r)
        kd = self.kd(r)
        if(kp < 0): # Fload > Fstall
            return(0,0)
        
        while(True):
          tp = -math.log(random.random())/kp
          td = -math.log(random.random())/kd
          if(tp < td): # move forward at t=t+tp
              t += tp
              if(mk_fig):
                self.x_list.append(x)
                self.t_list.append(t)
              x += self.d
              
          else: # motor detached
            t += td
            return(t,x)

    def plot(self):
        plt.plot(self.t_list,np.array(self.x_list)*1e6,"b.")

        plt.xlabel(r'$t (s)$',fontsize=22)
        plt.ylabel(r'$x (\mu m)$',fontsize=22)
        plt.show()

    def average_attached_time(self,N,r):
        """ Compute the average time and average displacement before the motor
            detaches.
            N : number of simulations
            r : radius of cargo
        """
        #### TO DO ####        

if __name__ == "__main__":

    # Plot a trajectory until detachment
    mot1=Motor()
    r = 1e-7 # 100 nm
    td = mot1.evolve(r,0.01,True)
    mot1.plot()

    # Compute Average t and x for r=1e-7m
    # and display the result on screen
    # Use the function average_attached_time
    #### TO DO #####


    # Figure of Average of t and x for r=0.1um to 100um by step on 0.5um
    #### TO DO ####
    

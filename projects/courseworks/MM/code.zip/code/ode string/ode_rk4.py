# Solve a system of ODE   
# dy/dt = F(y)
# where F and y are N components vectors
import numpy as np
import matplotlib.pyplot as plt

"""
The ode_rk4 module contains a class to integrate a system of ordinary
differential equations using the 4th order Runge Kutta method
"""

class OdeRk4:
  """A class to integrate a system of ODE using Runge Kutta 4th order"""

  def __init__(self):
     """
     Constructor: initialise a few internal variables
     """
     self.t = 0.0   # Integration variable
     self.dt = 0.0  # Integration step
     self.v = [0.0] # The functions for the equations
     self.l_t = []  # list of t values for figures
     self.l_f = []  # list of f values (arrays) for figures
     
  def set_dt(self,dt):
     """ Set the integration time step"""
     self.dt = dt

  def reset(self,t,dt,v0):
     """ Initialise the paramaters (t, dt and initial conditions) """
     self.t = t
     self.dt = dt
     self.v = np.array(v0, dtype='float64') # ensure we use floats!
     self.l_t = []  # list of t values for figures
     self.l_f = []  # list of f values (arrays) for figures
 
  def f(self,t,v):
      """ THIS FUNCTION MUST BE CHANGED IN THE CHILD CLASS
       Returns the right hand side of the equation: dv/dt = f(v,t) 
       t : current time
       v : curent fct value (a vector)
       """
      return(np.array(-1.0*v)) # example : dv/dt = -v


  def RK4_1step(self):
     """ Perform a single integration setp using
         the 4th order Runge Kutta step."""
     k1 = self.f(self.t,self.v)
     K = self.v+0.5*self.dt*k1

     k2 = self.f(self.t+0.5*self.dt,K)
     K = self.v+0.5*self.dt*k2

     k3 = self.f(self.t+0.5*self.dt,K)
     K = self.v+self.dt*k3
 
     k4 = self.f(self.t+self.dt,K)
     self.v += self.dt/6.0*(k1+2.0*(k2+k3)+k4)
    
     self.t += self.dt


  def solve_until(self,tmax,fig_dt=-1):
     """ Integrate equation up to tmax and add figure date in list
         l_t and l_f every fig_dt
         If fig_dt <= 0 : no data are not store in l_t and l_f 
     """
     next_fig_t = self.t+fig_dt
     # add initial value to figure data
     self.l_t.append(self.t)
     self.l_f.append(np.array(self.v))
     
     while(self.t <= tmax):
       self.RK4_1step()
       if(fig_dt > 0 and (self.t+self.dt*0.5) >next_fig_t):
         self.l_t.append(self.t)
         self.l_f.append(np.array(self.v)) # we must make a copy of v
         next_fig_t += fig_dt

  def plot(self,i,j,format="k-"):
    """ plot field i versus j using format
        i,j 0 : time
        i,j > 0 : v[i] or v[j]
    """

    if(i==0):
      lx = self.l_t
    else:
      lx = list(map (lambda v : v[i-1] , self.l_f))
    if(j==0):
      ly = self.l_t
    else:
      ly = list(map (lambda v : v[j-1] , self.l_f))
    #print(lx[0],ly[0])
    plt.plot(lx,ly,format);


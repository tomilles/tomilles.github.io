import sys
import ode_rk4
import numpy as np
import matplotlib.pyplot as plt

class StringOde(ode_rk4.OdeRk4):
  """A class derived from the class Ode_rk4.
  """
  def __init__(self,c,L,N):
      """Initialiser for our class. 
         c : string constant
         y : string extension : array of size N
         doty : dy/dt         : array of size N 
      """  
      ode_rk4.OdeRk4.__init__(self) # we can miss this out
      self.c = c
      self.N = N # number of points
      self.L = L
      self.dx = L/(N-1)
      self.dt = self.dx/(self.c*4)

  def reset(self,t,y,doty):
      """ Initialise the paramaters (t and initial conditions)
         y : spring extension : array of size N
         doty : df/dt         : array of size N 
      """
      self.t = t
     
      if (len(y) != self.N) or (len(doty) != self.N):
         print("spring.__init__ ERROR: invalid size for y or doty")
         sys.exit(5)

      self.v = np.empty(2*self.N, dtype='float64')
      # v[0:N]   : y
      # v[N:2*N] : dy/dt
      # ADD YOUR CODE HERE


      # Initialise lists for the figures
      self.l_t = []  # list of t values for figures
      self.l_f = []  # list of y values (arrays) for figure


  def f(self,t,v):
      """ equation to solve:
          DESCRIBE EQUATION HERE 
          t: current time 
          v: current function as a vector
      """
      F = np.zeros(2*self.N) # the array is created.  
      # ADD CODE HERE

      return(F)
###########################################
N = 200    # number of points

# ADD PARAMETERS HERE
L =           # length of string: 63cm
c =           # sound speed on the string
T=2*L/c       # period
tmax = 20*T   # integration time 
fig_dt=T/200  # interval between figure capture

#create StringOde  object, Call it spr
# ADD CODE HERE

# Initial condition
# ADD CODE HERE
y = 
doty = 

# Set the initial condition
# ADD CODE HERE

# Integrate until tmax with data saved every fig_dt
# ADD CODE HERE

# Plot Profile f(x) at regular interval
# ADD CODE HERE

plt.show()

# Plot Profile f(L/3) as a function of time
# ADD CODE HERE

plt.show()

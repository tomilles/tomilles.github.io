import numpy as np
from pulp import *
import time
from itertools import chain, combinations
import fractions
from rational import *
import random

# SPECIFY VERTICES AND EDGES: 

# vertices must be single-valued letters of type str() e.g. a,b,c
V=['a','b','c','d','e','f','g','h']

# edges must be str() type data formed by concatenating the relevant vertices
E=['be', 'ad', 'bf', 'ae', 'fg', 'ac', 'dg', 'bh', 'gh', 'bg', 'cg', 'eg', 'ag', 'af', 'eh', 'dh', 'ah', 'bd']

# ///create random edges ///
# if E==[]:
# 	for e in range(25):
# 		edge=random.sample(V,2)
# 		edge.sort()
# 		sample=(''.join(edge))
# 		if sample not in E:
# 			E.append('{0}'.format(sample))

def main(V,E):
	V.sort()
	E_ext=E.copy()
	for i in range(len(E)):				# make sure the reserved edges are in the loop too
		E.append(E[i][::-1])
	n=int(len(V))	
	S=[]		#subsets
	K=[]		#cliques
	for i in range(n+1):
		S.extend(list(itertools.combinations(V, i)))			#creating subsets
	for i in range(len(S)):
		mystring=''.join(S[i])
		S[i]+=('x_'+str(mystring),)
	S=list(S)
	K.extend(S[:n+1])

	for i in S[n+1:]:		#for each subset with at least 2 element
		K_edges=[]
		subset=(list(itertools.combinations(i[:-1], 2)))		#create all possible combinations of the elements of length 2
		for j in range(len(subset)):	
			# and if yes, then it is a clique
			edge=''.join(subset[j])
			K_edges.append(edge)
		if set(K_edges).issubset(E):
			K.append(i)				#we have a list of cliques

	xs=list(np.zeros(len(S),dtype=float))
	for k in range(len(S)):
		xs[k]=(S[k][-1])	
	return V,K,xs,S

def clique_var(V,K):
	constraints=[]
	for v in V:
		xs_list=[]
						#select cliques which has v in it
		for clique in K:
			if v in clique:
				xs_list.append(clique[-1])
		constraints.append(xs_list)
	return constraints

def LP1solver(constraints,xs,file):
	# Create the 'prob' variable to contain the problem data
	prob1 = LpProblem("fractional clique cover number", LpMinimize)

	# Create problem variables
	
	var_list=[]
	for i in constraints:
		var_list+=i
	var_list=list(set(var_list))

	for i in range(len(xs)):
		if xs[i] not in var_list:
			xs[i]=0.0

	for i in range(len(var_list)):
		var_list[i] = LpVariable("{0}".format(var_list[i]),0,None,LpContinuous)

	# The objective function is added to 'prob' first
	prob1 += sum(var_list)
	# The two constraints are entered

	var_list_copy=var_list.copy()
	for i in range(len(var_list_copy)):
		var_list_copy[i]=str(var_list_copy[i])

	for i in range(len(constraints)):
		for k in range(len(constraints[i])):
			index=var_list_copy.index(constraints[i][k])
			constraints[i][k] = var_list[index]


	for i in constraints:
		prob1+=sum(i)>=1

	# The problem is solved using PuLP's choice of Solver
	prob1.solve()

	# The status of the solution is printed to the screen
	file.write("LP1 Status:{0}".format(LpStatus[prob1.status]))

	# Each of the variables is printed with it's resolved optimum value
	x=xs.copy()
	for v in prob1.variables():
	    # print(v.name, "=", v.varValue)
	    index=xs.index(v.name)
	    x[index]=(v.varValue)
	# The optimised objective function value is printed to the screen
	for i in range(len(x)):
		x[i] = str(fractions.Fraction(x[i]))
 
	file.write("\nfractional clique cover number = {0}".format(str(fractions.Fraction(value(prob1.objective)))))
	file.write('\nand the corresponding vector x: [{0}]'.format(",".join(x)))
	return

def shannon_constraints(V,E,S,K):
	constraints_1=[]
	constraints_2=[]
	constraints_3=[]
	for v in V:
		neighbour_v=[]
		for i in E:
			if i[0]==v:
				neighbour_v.append(i[1])
		neighbour_v.sort()
		neighbour_v_inc=neighbour_v.copy()
		neighbour_v_inc.append(v)
		neighbour_v_inc.sort()
		# print(neighbour_v,neighbour_v_inc)
		x_neighbour_v='x_'+''.join(neighbour_v)
		x_neighbour_v_inc='x_'+''.join(neighbour_v_inc)
		constraints_1.append([x_neighbour_v_inc,x_neighbour_v])

			#subsets
	for s in S:				#creating subsets P of S for each S subset of V
		P=[()]
		for i in range(int(len(s)-1)):
			myvar=list(itertools.combinations(s[:-1], i+1))
			P.extend(myvar)
		for i in range(len(P)):
			P[i]=P[i]+(('x_'+''.join(P[i])),)

		to_add=[s[-1]]
		for i in P:
			to_add.append(i[-1])
		constraints_2.append(to_add)

	for s in S:
		for t in S:
			sub_constraint=[]
			xs=s[-1]
			xt=t[-1]
			myset_s=set(xs[2:])
			myset_t=set(xt[2:])

			#UNION
			myset=sorted(myset_s.union(myset_t))
			union='x_'+''.join(myset)

			#INTERSECTION
			myset=sorted(myset_t.intersection(myset_s))
			intersection='x_'+''.join(myset)
			#adding to the 3rd constraint
			sub_constraint.append([xs,xt,union,intersection])
			constraints_3.extend(sub_constraint)

	# print(S)
	return constraints_1,constraints_2,constraints_3

def LP2solver(constraints_1,constraints_2,constraints_3,S,V,file):
	prob2 = LpProblem("Shannon entropy", LpMaximize)	
	
	#list of xs
	xs=['x_']
	for s in S[1:]:
		xs.append(s[-1])


	for i in range(len(xs)):
		xs[i]=LpVariable("{0}".format(xs[i],0,None,cat=LpContinuous))
	#objective function
	prob2+=xs[-1]
	xs_copy=list(map(str,xs.copy()))

	prob2+=xs[0]==0							# easy, basic constraints
	for i in range(len(xs)):
		prob2+=xs[i]>=0.0
		if str(xs_copy[i][2:]) in V:
			prob2+=xs[i]<=1.0

	for con1 in constraints_1:
		# print(xs[xs_copy.index(con1[0])],xs[xs_copy.index(con1[1])])
		prob2+=xs[xs_copy.index(con1[0])]-xs[xs_copy.index(con1[1])]==0

	for con2 in constraints_2:
		for i in range(1,len(con2)-2):				# neglecting redundant calculations
			# print(xs[xs_copy.index(con2[0])],xs[xs_copy.index(con2[i+1])])
			prob2+=xs[xs_copy.index(con2[0])]-xs[xs_copy.index(con2[i+1])]>=0

	for con3 in constraints_3:
		if (con3[0]==con3[2] and con3[1]==con3[3]) or (con3[1]==con3[2] and con3[0]==con3[3]):		#filter out those which would give 0
			continue
		# print(xs[xs_copy.index(con3[0])],xs[xs_copy.index(con3[1])],xs[xs_copy.index(con3[2])],xs[xs_copy.index(con3[3])])
		prob2+=xs[xs_copy.index(con3[0])]+xs[xs_copy.index(con3[1])]-xs[xs_copy.index(con3[2])]-xs[xs_copy.index(con3[3])]>=0
	
	# The problem is solved using PuLP's choice of Solver
	prob2.solve()

	# The status of the solution is printed to the screen
	file.write("\n\nLP2 Status:{0}".format(LpStatus[prob2.status]))

	# Each of the variables is printed with it's resolved optimum value
	x=xs.copy()
	for v in prob2.variables():
	    # print(v.name, "=", v.varValue)
	    index=xs_copy.index(v.name)
	    x[index]=(v.varValue)
	for i in range(len(x)):
		x[i] = str(fractions.Fraction(x[i]))
	# The optimised objective function value is printed to the screen
	file.write("\nShannon entropy ={0}".format(str(fractions.Fraction(value(prob2.objective)))))
	file.write('\nand the corresponding vector x: [{0}]'.format(",".join(x)))
	return

if __name__ == '__main__':
	file=open("optimal_solution.txt",'w')
	file.write("V={0}\nE={1}\n\n".format(V,E))
	V,K,xs,S=main(V,E)

	constraints=clique_var(V,K)
	LP1solver(constraints,xs,file)
	con1,con2,con3 = shannon_constraints(V,E,S,K)
	LP2solver(con1,con2,con3,S,V,file)
	file.close()




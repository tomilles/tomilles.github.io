#####################################################################

# Example : load, display and cycle the ** left or right only ** image from a
# for a set of rectified stereo images from a  directory structure
# of left-images / right-images with filesname DATE_TIME_STAMP_{L|R}.png

# optionally load available IMU/GPS ground truth data

# basic illustrative python script for use with provided dataset

# Author : Toby Breckon, toby.breckon@durham.ac.uk

# Copyright (c) 2017 Department of Computer Science,
#                    Durham University, UK
# License : LGPL - http://www.gnu.org/licenses/lgpl.html

#####################################################################

import cv2
import os
import numpy as np
import csv
import math
import gyro     # local file gyro.py
from visual_odometry import PinholeCamera, VisualOdometry
from myyolo import yolo
#####################################################################

# where is the data ? - set this to where you have it

master_path_to_dataset = "/Users/Tomi/Downloads/TTBB-durham-02-10-17-sub5"; # ** need to edit this **

directory_to_cycle = "left-images";     # edit this for left or right image set

use_yolo = False        #enable or disable object detection 

# detector = "SIFT"             #choose which feature point detection to use
detector = "FAST"


bg = cv2.imread('durham_ground.png')
bg=cv2.resize(bg,(600,600))


bg_w=bg.shape[0]
bg_h=bg.shape[1]

#####################################################################

# full camera parameters - from camera calibration
# supplied images are stereo rectified

camera_focal_length_px = 399.9745178222656;  # focal length in pixels (fx, fy)
camera_focal_length_m = 4.8 / 1000;          # focal length in metres (4.8 mm, f)
stereo_camera_baseline_m = 0.2090607502;     # camera baseline in metres (B)
camera_height_above_wheelbase_m = (1608.0 + 31.75 + 90) / 1000; # in mm

optical_image_centre_h = 262.0;             # from calibration - cy
optical_image_centre_w = 474.5;             # from calibration - cx

image_height = 544;
image_width = 1024;

#####################################################################

# set this to a file timestamp to start from (empty is first example - outside lab)
# e.g. set to 1506943191.487683 for the end of the Bailey, just as the vehicle turns

skip_forward_file_pattern = ""; # set to timestamp to skip forward to

pause_playback = False; # pause until key press after each image

#####################################################################

# resolve full directory location of data set for images

full_path_directory =  os.path.join(master_path_to_dataset, directory_to_cycle);

# open ground truth GPS / IMU data files if available

gps_file_name = os.path.join(master_path_to_dataset, "GPS.csv");
imu_file_name = os.path.join(master_path_to_dataset, "IMU.csv");
gps_data = [];
imu_data = [];

if (os.path.isfile(gps_file_name)):
    with open(gps_file_name, newline='') as csvfileGPS:
        gps_data = list(csv.DictReader(csvfileGPS));
        print("-- using GPS data file: " + gps_file_name);
else:
        print("-- GPS data file not found: " + gps_file_name);

if (os.path.isfile(imu_file_name)):
    with open(imu_file_name, newline='') as csvfileIMU:
        imu_data = list(csv.DictReader(csvfileIMU));
        print("-- using IMU data file: " + imu_file_name);
else:
        print("-- IMU data file not found: " + imu_file_name);

# get a list of the files, sort them (by timestamp in filename) and iterate

cam = PinholeCamera(1024.0, 544.0, 399.9745178222656, 399.9745178222656, 474.5, 262.0)
vo = VisualOdometry(cam,detector)
# traj = np.zeros((1000,1000,3), dtype=np.uint8)
if skip_forward_file_pattern == "":
    traj = bg
    durham = True           #if starts from beginning, add the durham satellite (later) and rotate accordingly (later)
else:
    traj = np.zeros_like(bg, dtype=np.uint8)
    durham = False

groundtraj = np.zeros_like(bg, dtype=np.uint8)
print('begin')
index2=0


for index, filename in enumerate(sorted(os.listdir(full_path_directory))):

    # skip forward to start a file we specify by timestamp (if this is set)

    if ((len(skip_forward_file_pattern) > 0) and not(skip_forward_file_pattern in filename)):
        continue;
    elif ((len(skip_forward_file_pattern) > 0) and (skip_forward_file_pattern in filename)):
        index2=index
        skip_forward_file_pattern = "";
    # from image filename get the correspondoning full path

    full_path_filename = os.path.join(full_path_directory, filename);

    # for sanity print out these filenames

    print(full_path_filename);

    # check the file is a PNG file (left) and check a correspondoning right image
    # actually exists

    if ('.png' in filename) and (os.path.isfile(full_path_filename)) :

        # read left and right images and display in windows
        # N.B. despite one being grayscale both are in fact stored as 3-channel
        # RGB images so load both as such

        img = cv2.imread(full_path_filename, 1)
        gray_img = cv2.imread(full_path_filename, 0)

        print("-- file loaded successfully");
        print("\n");

        

        ####################################################################


        # @@@ monocular visual odometry @@@ 
        if use_yolo:
            # print
            boxes = yolo(full_path_filename).main()   #get bounding boxes of dynamic objects
            # print((boxes))
            boxes.append([30, 390, 964, 154])
            for detected_object in range(0, len(boxes)):                #draw boxes around detected objects
                        box = boxes[detected_object]
                        left = box[0]
                        top = box[1]
                        width = box[2]
                        height = box[3]
                        cv2.rectangle(img, (left, top), (left + width, top + height), (255, 178, 50),2)
            
            fp = vo.update(gray_img,boxes, yolo = use_yolo)     # get feature points 
        else:
            fp = vo.update(gray_img, yolo = use_yolo)

        ##### display gps and imu info on pics #####
        # cv2.putText(img,detector,(20,20),cv2.FONT_HERSHEY_PLAIN, 1, (255,0,0), 1, 12)
        # cv2.putText(traj,detector,(20,20),cv2.FONT_HERSHEY_PLAIN, 1, (255,0,0), 1, 12)
        # if (len(gps_data) >= index):
        #     text = "GPS: lat.=%2f long.=%2f alt.=%2f"\
        #         %(float(gps_data[index]['latitude']),
        #         float(gps_data[index]['longitude']),
        #         float(gps_data[index]['altitude']));
        #     cv2.putText(img, text, (20,40), cv2.FONT_HERSHEY_PLAIN, 1, (0,0,255), 1, 12)

        # if (len(imu_data) >= index):

        #     roll, pitch, heading = gyro.gyro_to_angles(
        #                 float(imu_data[index]['orientation_x']),
        #                 float(imu_data[index]["orientation_y"]),
        #                 float(imu_data[index]['orientation_z']),
        #                 float(imu_data[index]['orientation_w']));

        #     text = "IMU: roll/pitch/heading. (%2f, %2f, %2f) "\
        #         %(roll, pitch, heading);
        #     cv2.putText(img, text, (20,60), cv2.FONT_HERSHEY_PLAIN, 1, (0,0,255), 1, 12)

        #     text = "IMU: angular velocity (%2f, %2f, %2f)"\
        #         %(float(imu_data[index]['angular_velocity_x']),
        #         float(imu_data[index]['angular_velocity_y']),
        #         float(imu_data[index]['angular_velocity_z']));
        #     cv2.putText(img, text, (20,80), cv2.FONT_HERSHEY_PLAIN, 1, (0,0,255), 1, 12)

        #     text = "IMU: accel. (%2f, %2f, %2f)"\
        #         %(float(imu_data[index]['linear_acceleration_x']),
        #         float(imu_data[index]['linear_acceleration_y']),
        #         float(imu_data[index]['linear_acceleration_z']));
        #     cv2.putText(img, text, (20,100), cv2.FONT_HERSHEY_PLAIN, 1, (0,0,255), 1, 12)
###################################

        

        cur_t = vo.cur_t        #get translation of feature points
        # print((cur_t))
        if(index-index2 > 2):
            x, y, z = cur_t[0], cur_t[1], cur_t[2]

        else:
            x, y, z = 0., 0., 0.
            if durham:
                origin_x,origin_y = round(bg_w*0.83), round(bg_h*0.955)
            else:
                origin_x,origin_y = round(bg_w*0.5), round(bg_h*0.5)

        cv2.circle(traj, (origin_x,origin_y), 5, (0,0,255), 5)  #mark origin

        
        if durham:
            draw_x, draw_y = int(x)+int(bg_w*0.83), int(-z)+int(bg_h*0.955)
            angle=(math.pi / 2)                # rotate location points to fit durham map
            rotated_draw_x = round(origin_x + math.cos(angle) * (draw_x - origin_x) - math.sin(angle) * (draw_y - origin_y))
            rotated_draw_y = round(origin_y + math.sin(angle) * (draw_x - origin_x) + math.cos(angle) * (draw_y - origin_y))
            draw_x = rotated_draw_x
            draw_y = rotated_draw_y
        else: 
            draw_x, draw_y = int(x)+int(bg_w*0.5), int(-z)+int(bg_h*0.5)
        
        # true_x, true_y = int(vo.trueX)+290, int(vo.trueZ)+90

        cv2.circle(traj, (draw_x,draw_y), 1, (255,0,0), 1)
        
        # cv2.circle(traj, (true_x,true_y), 1, (0,0,255), 2)
        cv2.rectangle(traj, (10, 20), (600, 60), (135,135,135), -1)
        text = "Coordinates: x=%2fm y=%2fm z=%2fm"%(x,y,z)
        cv2.putText(traj, text, (20,40), cv2.FONT_HERSHEY_PLAIN, 1, (0,0,0), 1, 8)

        #####################################################################

        
        # # display the image
        # print(fp.shape)
        # cv2.circle(img, , 1, (255,0,0), 1)

        # img=cv2.drawKeypoints(img,fp,img)

        # cv2.circle(traj, (origin_x,origin_y), 5, (0,0,255), 5)

        # print(fp)
        for point in fp:
            cv2.circle(img, tuple(point),1,(57,255,20),1)

        

        cv2.namedWindow("Trajectory", cv2.WINDOW_NORMAL)
        cv2.resizeWindow('Trajectory', 400,400)
        cv2.imshow('Trajectory', traj)
        cv2.namedWindow("input image", cv2.WINDOW_NORMAL)
        cv2.resizeWindow('input image', 753,400)
        cv2.imshow('input image',img)
        cv2.waitKey(1)
        cv2.imwrite("input.png", img)
        if index % 10 ==0 :
            cv2.imwrite("trajectory.png", traj)


        
        # keyboard input for exit (as standard), save disparity and cropping
        # exit - x
        # save - s
        # pause - space

        key = cv2.waitKey(40 * (not(pause_playback))) & 0xFF; # wait 40ms (i.e. 1000ms / 25 fps = 40 ms)
        if (key == ord('x')):       # exit
            break; # exit
        elif (key == ord('s')):     # save
            cv2.imwrite("input.png", img);
        elif (key == ord(' ')):     # pause (on next frame)
            pause_playback = not(pause_playback);
    else:
            print("-- files skipped (perhaps one is missing or not PNG)");
            print("\n");
cv2.imwrite("trajectory.png", traj)
# close all windows

cv2.destroyAllWindows()

#####################################################################

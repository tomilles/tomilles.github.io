import numpy as np
import pandas as pd 
import csv
import random
import math



class tableclass(object):
	def __init__(self,file):
		print('init')
		self.file=file
		self.temp=10000
		self.pathlist=[]
		self.costlist=[]



	def input(self):
		f=open(("{0}.txt".format(self.file)),'r')
		content=f.read().split(',')
		self.size=int(content[1].split()[-1])
		self.sizelist=list(reversed(np.arange(1,self.size)))
		content=content[2:]
		for j in range(len(content)):
			X=content[j]
			Y=str()
			for i in range(len(X)):
				try:
					Y=Y+str(int(X[i]))
				except ValueError:
					pass
			content[j]=int(Y)
		X=np.zeros((self.size,self.size),dtype=float)
		f=0
		t=0
		for i in range(self.size):
			t=self.size-1-i+t
			y=np.array(content[f:t])
			X[i,i+1:]=y
			X[i+1:,i]=y
			f=t
		for i in X:
			i[i==0]=np.inf	#setting zeros to infinity
		self.table=X.copy()
		return X

	def init_path(self):
		randomlist=list(np.arange(0,self.size))
		# print(pd.DataFrame(table))
		table=self.table.copy()
		path=list([random.choice(randomlist)])
		table[:,path[-1]]=np.inf
		for i in range(len(table)):
			minimum_ind=list(table[path[-1]]).index(min(table[path[-1]]))
			path.append(minimum_ind)
			table[:,path[-1]]=np.inf
			# print(pd.DataFrame(table))
		# path.append(path[0])
		self.path=path[:-1].copy()
		return self.path

	def costfunction(self,path):
		# print('costfunction')
		cost=0
		for i in range(len(path)-1):
			cost+=self.table[path[i],path[i+1]]
			# print('loop')
		cost+=self.table[path[-1],path[0]]
		return cost

	def pathfunction(self,currentcost,temp=10000,beta=1.0001):
		# print('pathfunction')
		while temp>0.00001:
			path=self.path.copy()
			# print('path is ',path)
			temp=temp/beta
			# print(temp)

			a=random.choice(path)
			path_b=path.copy()
			path_b.remove(a)
			b=random.choice(path_b)
			a_index=path.index(a)
			b_index=path.index(b)

			if path[a_index:b_index]!=[]:
				testour=path[a_index+1:b_index]
				path[a_index+1:b_index]=list(reversed(testour))
			elif path[a_index:b_index]==[]:
				testour=path[b_index+1:a_index]
				path[b_index+1:a_index]=list(reversed(testour))

			newcost=self.costfunction(path)
			# print('newcost is ',newcost)
			delta_E=currentcost-newcost

			if delta_E>=0:
				self.path=path.copy()
				# print('newcost is ',newcost, 'currentcost is', currentcost)
				currentcost=newcost

			elif delta_E<0:
				# print('else')
				prob=1/(np.exp(abs(delta_E)/temp))
				# print('change from ',currentcost,' to ', newcost, ' with probability ',prob)
				if random.random()<prob:
					self.path=path.copy()

					currentcost=newcost
		
		(self.pathlist).append(self.path)
		cost=self.costfunction(self.path)
		self.costlist.append(cost)
		# print('done')


	def costcheck(self):
		# print('costcheck')
		print(self.costlist)
		mincost=min(self.costlist)
		mincost_index=self.costlist.index(mincost)
		optimal=self.pathlist[mincost_index]
		return (mincost,optimal)

	# def output(self,cost,optimal):
	# 	filename="tour{0}.txt".format(file)
	# 	optimal=list(np.array(optimal)[:]+1)
	# 	output=["NAME = {0},".format(file),"TOURSIZE = {0},".format(self.size),"LENGTH = {0},".format(int(cost)),'{0}'.format(",".join(map(repr,optimal)))]
	# 	np.savetxt(r"/Users/Tomi/Dropbox/AI/main/dcs0ias/TourfileB/{0}".format(filename),output,fmt="%s")
		


if __name__ == "__main__":
	file="AISearchfile180"
	t=tableclass(file)
	table=t.input()

	path=t.init_path()
	cost=t.costfunction(path)
	# print(path)
	t.pathfunction(cost)

	print(t.costcheck())



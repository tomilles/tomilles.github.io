import numpy as np
import pandas as pd 
import csv
import random
import math



class tableclass(object):
	def __init__(self,file):
		self.file=file
		self.row_col_scaning=[['row scanning'],['column scanning']]
		self.deleted_count=[0,0]
		self.init_reduced=self.reduction(self.input())
		self.indices=[]
		self.original_table=self.input()
		self.firstrowindices=[]
		self.optimal_routes=[]
		self.prev_min=[np.inf]
		self.min_list=[]



	def input(self):
		# print("input")
		f=open(("{0}.txt".format(self.file)),'r')
		content=f.read().split(',')
		self.size=int(content[1].split()[-1])
		self.sizelist=list(reversed(np.arange(1,self.size)))
		content=content[2:]
		for j in range(len(content)):
			X=content[j]
			Y=str()
			for i in range(len(X)):
				try:
					Y=Y+str(int(X[i]))
				except ValueError:
					pass
			content[j]=int(Y)
		X=np.zeros((self.size,self.size),dtype=float)
		f=0
		t=0
		for i in range(self.size):
			t=self.size-1-i+t
			y=np.array(content[f:t])
			X[i,i+1:]=y
			X[i+1:,i]=y
			f=t
		for i in X:
			i[i==0]=np.inf	#setting zeros to infinity

		return X

	def reduction(self,table):
		# print("reduction")
		index=[]
		count=1
		for i in table:
			minimum=int(min(i))
			i[:]=i[:]-minimum	#subtracting the minimum of each row from each element in the given row
		for i in np.transpose(table):
			minimum=min(i)
			i[:]=i[:]-minimum
			index.append("city{0}".format(count))
			count=count+1
		return table


	def scaning(self,newtable):
		# print("row/col scanning")
		oldtable=np.zeros(newtable.shape)

		while (np.nan_to_num(newtable,copy=True)==np.nan_to_num(oldtable,copy=True)).all()==False:
			oldtable=np.array(newtable)
			for j in range(2):	
				# print(self.row_col_scaning[j][0])
				zeros=np.array([])
				count=0
				i=0
				while i < len(newtable):
					zeros=np.append(zeros,len(newtable[i])-np.count_nonzero(newtable[i]))
					
					if zeros[-1]==1:
						indices=list(newtable[i]).index(0)
						newtable[:,indices]=len(newtable)*[np.nan]
						if j==0:
							y=[i,indices]
						elif j==1:
							y=[indices,i]

					i=i+1
				newtable=np.transpose(newtable)

		return newtable

	def scan_for_0(self,newtable):
		while newtable.all()==0:
			i=0
			while newtable[i].all()!=0 :
				i=i+1
			
			indices_row_zero=list(np.where(newtable[i]==0)[0])
			cols_with_zero=(newtable[:,indices_row_zero[:]])
			k=0
			while len(indices_row_zero)!=list(cols_with_zero[k]).count(0):
				k=k+1
			indices_row_zero=np.where(newtable[k]==0)[0]

			newtable[k]=[np.nan]*len(newtable[k])
			newtable=self.scaning(newtable)
		return(newtable)


	def N_check(self,newtable):
		# print("N_check")
		N_lines=0
		cross_row=[]
		cross_col=[]
		newtable_nonan=np.nan_to_num(newtable,copy=True)
		for i in range(len(newtable)):
			if newtable_nonan[i].any()==0:
				N_lines+=1
				for j in range(len(newtable[i])):
					if newtable_nonan[:,j].any()==0:
						cross_col.append(j)
						cross_row.append(i)

			if newtable_nonan[:,i].any()==0:
				N_lines+=1
		cross_indices=list([cross_row,cross_col])
		if newtable_nonan.any()==0:
			N_lines=len(newtable_nonan)
			cross_indices=0

		return (N_lines,cross_indices)

	def optimal_test(self,newtable,N_lines,cross_indices):
		# print("optimal_test")
		if N_lines==len(self.init_reduced):
			# print("optimal")
			newtable=np.array(self.init_reduced)
			noninf_table=np.array(newtable)
			for i in noninf_table:					#calculating maximum 
				i[i==np.inf]=-np.inf	
			self.maximum=int(max(noninf_table.max(axis=0)))

			for i in range(self.maximum):
				if i in newtable:					#list of min numbers in the matrix
					self.min_list.append(i)

			self.min_list_2=self.min_list[1:].copy()	#copy of min list
			x=self.indices_func(newtable,0.).copy()
			for i in x:
				self.indices=[]
				self.indices_func(newtable,0.)
				try:
					# print('try')
					self.route_check(newtable,0.,i)
					# self.prev_min.append(self.minimum)
					# print(self.lastmin,'lastmin')
				except RecursionError:
					# print('pass')
					pass
			self.optimal_routes=np.array(self.optimal_routes)
			return ("optimal")

		else:
			# print("not optimal")

			minimum=np.nanmin((newtable))
			nonnan_index=list(np.where(~np.isnan(newtable)))
			self.init_reduced[nonnan_index]-=minimum
			self.init_reduced[cross_indices]+=minimum
			newtable=np.array(self.init_reduced)			
			self.execute(newtable)
			return self.init_reduced
			

	def indices_func(self,table,minimum):
		# print('indices_func')
			# increasing the indices list by the indices of cells with the lowest element in the matrix
		for i in range(len(table)):
			if minimum in table[i]:
				where=np.where(table[i]==minimum)[0]
				for j in where:
					self.indices.append([i+1,j+1])
		if minimum==0:
			for i in self.indices:
				if i[0]==1:
					self.firstrowindices.append(i)
		return self.firstrowindices



	def route_check(self,table,minimum,init_route):
		# print("route check")
		route=[init_route]
		dest=(self.indices).copy()
		u=0
		while u != len(dest):						#creating route
			y=np.array(route)[:,0]
			if route[-1][1]==dest[u][0] and (dest[u][1] not in y):
				route.append(dest[u])
				dest.remove(dest[u])
				u=0
			elif route[-1][1]==dest[u][0] and len(table)==len(route)+1 and route[0][0]==dest[u][1] and (dest[u][1] not in y[1:]):
				route.append(dest[u])
				dest.remove(dest[u])
				u=0

			else:
				u=u+1

		
		while minimum<=min(self.prev_min):
			# print(minimum,min(self.prev_min))
			if len(route)!=len(table):		#if the route is not = with the number of cities, solution is not optimal
				# print("not good")
				# for k in np.reshape(table,(1,len(table)**2)):
				# 	print(3 in k)
				# min_list=list(self.min_list)
				minimum=self.min_list_2[0]
				self.lastmin=minimum
				del self.min_list_2[0]
				while minimum<=self.maximum:
					self.indices_func(table,minimum)		# increase indices list
					if self.route_check(table,minimum,init_route)=="optimal route":
						# print('here comes the break')
						break
						return
										# check for route with the increased list
					else:
						break
				return
			if len(route)==len(table):		#optimal route found
				if np.inf in self.prev_min:			# take out inf from the list for it to work properly in the future
					self.prev_min.remove(np.inf)
				# print("optimal route found")
				# print(minimum)
				self.minimum=minimum
				self.optimal_routes.append(route)
				self.prev_min.append(self.minimum)
				# print(self.prev_min)
				self.min_list_2=self.min_list[1:]
				# minimum=self.min_list_2[0]
				# del self.min_list_2[0]

				return "optimal route"


	def cost_check(self):
		# print("costcheck")
		self.optimal_routes=self.optimal_routes[self.prev_min.index(min(self.prev_min))]
		optimal=[]
		cost=0
		for i in self.optimal_routes:
			cost+=self.original_table[i[0]-1,i[1]-1]
			optimal.append(i[0])
		optimal.append(self.optimal_routes[-1][-1])
		# print('total cost is ',cost)
		# print('min considered value: ',min(self.prev_min))
		# print(optimal)
		return (cost,optimal)
		


	def execute(self,table_reduced):
		newtable=self.scan_for_0(self.scaning(table_reduced))
		(N_lines,cross_indices) = self.N_check(newtable)
		self.optimal_test(newtable,N_lines,cross_indices)


	def output(self,cost,optimal):
		filename="tour{0}.txt".format(file)
		output=["NAME = {0},".format(file),"TOURSIZE = {0},".format(self.size),"LENGTH = {0},".format(int(cost)),'{0}'.format(",".join(map(repr,optimal[:-1])))]
		np.savetxt(r"/Users/Tomi/Dropbox/AI/main/dcs0ias/TourfileA/{0}".format(filename),output,fmt="%s")
		


if __name__ == "__main__":
	filesize=list(['012','017','021','026','042','048','058','175','180','535'])
	for i in filesize:
		file="AISearchfile{0}".format(i)
		print(file)
		t=tableclass(file)
		table=t.input()
		table=t.reduction(table)
		t.execute(table)
		(cost,optimal)=t.cost_check()
		t.output(cost,optimal)


	

